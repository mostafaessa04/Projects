########### Simple desition making project from some premise ############# 
######################### By Mostafa Essa ################################

statement = "if i am a programmer, i know how to code. if i know how to code, i study well. i not study well." # the input statement

# Rules of inference:
##########################################################

# Modus Ponens:

def modus_ponens(premise1, premise2):
    if premise1.find('->') == -1 and premise2.find('->') != -1:
        if premise2.find(premise1 + '->') != -1 and premise2.find('~' + premise1) == -1:
            return premise2[premise2.find('-> ')+3:]
    if premise2.find('->') == -1 and premise1.find('->') != -1:
        if premise1.find(premise2 + '->') != -1 and premise1.find('~' + premise2) == -1:
            return premise1[premise1.find('-> ')+3:]
    return -1
#Modus Tollens:

def modus_tollens(premise1, premise2):
    if premise1.find('->') == -1 and premise2.find('->') != -1:
        if premise2.find('-> ~' + premise1):
            if premise2[:premise2.find(' ->')].find('~') != -1:
                return premise2[premise2[:premise2.find('->')].find('~')+1:]
            else:
                return '~' + premise2[:premise2.find(' ->')]
        premise1_temp = premise1.replace('~', '')
        if premise1.find('~') and premise2.find('-> ' + premise1_temp):
            if premise2[:premise2.find(' ->')].find('~') != -1:
                return premise2[premise2[:premise2.find('->')].find('~')+1:]
            else:
                return '~' + premise2[:premise2.find(' ->')] 
    
    if premise2.find('->') == -1 and premise1.find('->') != -1:
        if premise1.find('-> ~' + premise2):
            if premise1[:premise1.find(' ->')].find('~') != -1:
                return premise1[premise1[:premise1.find('->')].find('~')+1:]
            else:
                return '~' + premise1[:premise1.find(' ->')]
        premise2_temp = premise2.replace('~', '')
        if premise2.find('~') and premise1.find('-> ' + premise2_temp):
            if premise1[:premise1.find(' ->')].find('~') != -1:
                return premise1[premise1[:premise1.find('->')].find('~')+1:]
            else:
                return '~' + premise1[:premise1.find(' ->')] 
    return -1

#Hypothotical Syllogism

def hypothotical_syllogism(premise1, premise2):
    if premise1.find('->') and premise2.find('->'):
        if premise2[:premise2.find(' ->')] == premise1[premise1.find('-> ')+3:]:
            return premise1[:premise1.find(' ->')] + ' -> ' + premise2[premise2.find('-> ')+3:]
        if premise1[:premise1.find(' ->')] == premise2[premise2.find('-> ')+3:]:
            return premise2[:premise2.find(' ->')] + ' -> ' + premise1[premise1.find('-> ')+3:]
    return -1

###############################################

################# The main ####################

###############################################

# Extract the premises:

Premises = []
Proposition = ""
prev = ''
for i in statement:
    if i == '.':
        if Proposition:
            Premises.append(Proposition)
        Proposition = ""
        prev = '.'
        continue
    if prev == '.':
        prev = ' '
        continue
    Proposition += i
    prev = i

print('The premises are:')
for premise in Premises:
    print(premise)
# Extract the variables:
Variables = {}
variable = 0
variables_Premises = {}
number_of_premise = 0
for Premise in Premises:
    if Premise.find('if') != -1:
        temp1 = Premise[:Premise.find(',')]
        temp2 = Premise[Premise.find(',')+2:]
        temp2 = temp2.replace('.', '')
        if temp1.find('not') != -1:
            temp1 = temp1.replace('not ', '')
        temp1 = temp1.replace('if ', '')
        if temp2.find('not') != -1:
            temp2 = temp2.replace('not ', '')
        ok = 0
        for item, text in Variables.items():
            if text == temp1:
                ok = item
                break
        if ok == 0:
            variables_Premises[number_of_premise] = variable
            number_of_premise = number_of_premise + 1
            Variables[variable] = temp1
            variable = variable + 1
        else:
            variables_Premises[number_of_premise] = ok
            number_of_premise = number_of_premise + 1
        ok = 0
        for item, text in Variables.items():
            if text == temp2:
                ok = 1
                break
        if ok == 0:
            variables_Premises[number_of_premise] = variable
            number_of_premise = number_of_premise + 1
            Variables[variable] = temp2
            variable = variable + 1
        else:
            variables_Premises[number_of_premise] = ok
            number_of_premise = number_of_premise + 1
        
    else:
        if Premise.find('not'):
            temp = Premise
            temp = temp.replace('not ', '')
            ok = 0
            for item, text in Variables.items():
                if text == temp:
                    ok = item
                    break
            if ok == 0:
                variables_Premises[number_of_premise] = variable
                number_of_premise = number_of_premise + 1
                Variables[variable] = temp
                variable = variable + 1
            else:
                variables_Premises[number_of_premise] = ok
                number_of_premise = number_of_premise + 1
print('--------------------------------------------------------------')
print('The variables are:')
for variable, text in Variables.items():
    print(f"{chr(variable+80)}: {text}")
Premises_in_chars = []
counter = 0
for Premise in Premises:
    if Premise.find('if') != -1:
        NOT1 = ''
        NOT2 = ''
        temp1 = Premise[:Premise.find(',')]
        temp2 = Premise[Premise.find(',')+2:]
        temp2 = temp2.replace('.', '')
        if temp1.find('not') != -1:
            NOT1 = '~'
        if temp2.find('not') != -1:
            NOT2 = '~'
        Premises_in_chars.append(NOT1 + chr(variables_Premises[counter]+80) + ' -> ' + NOT2 +chr(variables_Premises[counter+1]+80))
        counter = counter + 2
    else:
        NOT = ''
        if Premise.find('not') != -1:
            NOT = '~'
        Premises_in_chars.append('~'+chr(variables_Premises[counter]+80))
        counter = counter + 1
print('--------------------------------------------------------------')
print('The premises using the variables are:')
for Premise in Premises_in_chars:
    print(Premise)
vis = []
for i in range(len(Premises)):
    vis.append(0)

for i in range(len(Premises_in_chars)):
    if vis[i] == 1:
        continue
    j = i + 1
    while j < len(Premises_in_chars):
        if vis[j] == 1 or vis[i] == 1:
            j = j + 1
            continue
        if modus_ponens(Premises_in_chars[i], Premises_in_chars[j]) != -1:
            vis[i] = 1
            vis[j] = 1
            Premises_in_chars.append(modus_ponens(Premises_in_chars[i], Premises_in_chars[j]))
            vis.append(0)
            j = j + 1
            print('--------------------------------------------------------------')
            print(f"Using Modus Ponens to the premise {i+1} and {j+1}, the current Premises are:")
            for Premise in Premises_in_chars:
                print(Premise)
            continue
        if modus_tollens(Premises_in_chars[i], Premises_in_chars[j]) != -1:
            vis[i] = 1
            vis[j] = 1
            Premises_in_chars.append(modus_tollens(Premises_in_chars[i], Premises_in_chars[j]))
            vis.append(0)
            print('--------------------------------------------------------------')
            print(f"Using Modus Tollens to the premise {i+1} and {j+1}, the current Premises are:")
            for Premise in Premises_in_chars:
                print(Premise)
            j = j + 1
            continue
        if hypothotical_syllogism(Premises_in_chars[i], Premises_in_chars[j]) != -1:
            vis[i] = 1
            vis[j] = 1
            Premises_in_chars.append(hypothotical_syllogism(Premises_in_chars[i], Premises_in_chars[j]))
            vis.append(0)
            j = j + 1
            print('--------------------------------------------------------------')
            print(f"Using Hypothetical Syllogism to the premise {i+1} and {j+1}, the current Premises are:")
            for Premise in Premises_in_chars:
                print(Premise)
            continue
        j = j + 1
conclusion = Premises_in_chars.pop()
print('--------------------------------------------------------------')
print(f'The conclusion is {conclusion}')
